let map;
let userLocation = null;
let markers = [];
let heatmap = null;
let alerts = [];

function initMap() {
    console.log('ALERTX: Initializing custom heatmap...');
    window.mapInitialized = true;
    
    // Always use custom heatmap - no Google Maps dependency
    initCustomHeatmap();
}

function initGoogleMaps() {
    // Google Maps implementation
    map = new google.maps.Map(document.getElementById("map"), {
        zoom: 13,
        center: { lat: 12.9716, lng: 77.5946 },
        styles: [
            {
                "featureType": "all",
                "elementType": "geometry",
                "stylers": [{"color": "#f5f5f5"}]
            },
            {
                "featureType": "water",
                "elementType": "geometry",
                "stylers": [{"color": "#c9e4f7"}]
            }
        ]
    });
    
    loadCrimeData();
    loadAnalytics();
    setupEventListeners();
    requestNotificationPermission();
}

function initCustomHeatmap() {
    // Custom heatmap implementation with modern colorful design
    const mapDiv = document.getElementById("map");
    mapDiv.innerHTML = `
        <div style="height: 100%; position: relative; background: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460); border-radius: 20px; overflow: hidden; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);">
            <canvas id="heatmapCanvas" style="width: 100%; height: 100%; cursor: crosshair; border-radius: 20px;"></canvas>
            <div id="tooltip" style="position: absolute; background: linear-gradient(135deg, rgba(102, 126, 234, 0.95), rgba(118, 75, 162, 0.95)); color: white; padding: 12px 16px; border-radius: 12px; font-size: 13px; pointer-events: none; display: none; z-index: 1000; box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.2);"></div>
            <div style="position: absolute; top: 25px; left: 25px; background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(20px); padding: 20px; border-radius: 16px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2); border: 1px solid rgba(255, 255, 255, 0.3); max-width: 280px;">
                <h4 style="margin: 0 0 15px 0; color: #333; font-weight: 700; font-size: 16px; display: flex; align-items: center; gap: 8px;">
                    <span style="font-size: 24px;">🚨</span>
                    ALERTX Bangalore Crime Heatmap
                </h4>
                <div style="display: flex; flex-direction: column; gap: 12px;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <div style="width: 16px; height: 16px; background: linear-gradient(135deg, #4caf50, #8bc34a); border-radius: 4px; box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);"></div>
                        <span style="font-size: 12px; color: #333; font-weight: 600;">Low Risk (Score ≤ 10)</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <div style="width: 16px; height: 16px; background: linear-gradient(135deg, #ff9800, #ffc107); border-radius: 4px; box-shadow: 0 4px 12px rgba(255, 152, 0, 0.3);"></div>
                        <span style="font-size: 12px; color: #333; font-weight: 600;">Medium Risk (Score 11-25)</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <div style="width: 16px; height: 16px; background: linear-gradient(135deg, #f44336, #ff6b6b); border-radius: 4px; box-shadow: 0 4px 12px rgba(244, 67, 54, 0.3);"></div>
                        <span style="font-size: 12px; color: #333; font-weight: 600;">High Risk (Score > 25)</span>
                    </div>
                </div>
                <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #e0e0e0;">
                    <div style="font-size: 11px; color: #666; line-height: 1.4;">
                        <strong>💡 Tips:</strong><br>
                        • Hover over areas for detailed crime stats<br>
                        • Your location appears as blue pulsing dot<br>
                        • Red zones require extra caution
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Initialize canvas
    const canvas = document.getElementById('heatmapCanvas');
    if (!canvas) {
        console.error('ALERTX: Canvas not found!');
        return;
    }
    
    const ctx = canvas.getContext('2d');
    if (!ctx) {
        console.error('ALERTX: Canvas context not found!');
        return;
    }
    
    console.log('ALERTX: Canvas initialized successfully');
    
    // Set canvas size
    function resizeCanvas() {
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        console.log('ALERTX: Canvas resized to', canvas.width, 'x', canvas.height);
        drawHeatmap();
    }
    
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();
    
    // Store canvas context globally
    window.heatmapCtx = ctx;
    window.heatmapCanvas = canvas;
    
    console.log('ALERTX: Loading crime data...');
    loadCrimeData();
    loadAnalytics();
    setupEventListeners();
    requestNotificationPermission();
    
    console.log('ALERTX: Custom heatmap initialization complete!');
}

function setupEventListeners() {
    document.getElementById('locationBtn').addEventListener('click', getUserLocation);
    document.getElementById('manualLocationBtn').addEventListener('click', setManualLocation);
    document.getElementById('refreshBtn').addEventListener('click', refreshData);
    document.getElementById('simulateBtn').addEventListener('click', simulateAlert);
}

function setManualLocation() {
    showModal(`
        <div style="text-align: center;">
            <div style="font-size: 48px; margin-bottom: 20px;">📍</div>
            <h4 style="color: #667eea; margin-bottom: 20px;">Choose Bangalore Location</h4>
            
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 10px; font-weight: 600; font-size: 16px;">🏙️ Select Area:</label>
                <select id="areaSelect" style="width: 100%; padding: 12px; border: 2px solid #667eea; border-radius: 8px; font-size: 16px; background: white;">
                    <option value="">Choose Bangalore area...</option>
                    <option value="12.9716,77.5946,MG Road">MG Road (560001)</option>
                    <option value="12.9763,77.5713,Majestic">Majestic (560003)</option>
                    <option value="12.9279,77.6271,Koramangala">Koramangala (560034)</option>
                    <option value="12.9784,77.6408,Indiranagar">Indiranagar (560038)</option>
                    <option value="12.9698,77.7499,Whitefield">Whitefield (560066)</option>
                    <option value="12.9258,77.5803,Jayanagar">Jayanagar (560041)</option>
                    <option value="12.9405,77.5657,Basavanagudi">Basavanagudi (560004)</option>
                    <option value="12.9116,77.6489,HSR Layout">HSR Layout (560102)</option>
                    <option value="12.9591,77.6987,Marathahalli">Marathahalli (560037)</option>
                    <option value="12.8399,77.6770,Electronic City">Electronic City (560100)</option>
                    <option value="12.9166,77.6101,BTM Layout">BTM Layout (560076)</option>
                    <option value="12.8701,77.5803,Bannerghatta Road">Bannerghatta Road (560076)</option>
                    <option value="13.0955,77.5967,Yelahanka">Yelahanka (560064)</option>
                    <option value="13.0356,77.5967,Hebbal">Hebbal (560024)</option>
                    <option value="13.1986,77.7066,Airport Road">Airport Road (560017)</option>
                    <option value="12.9795,77.6055,Commercial Street">Commercial Street (560001)</option>
                    <option value="12.9775,77.6074,Brigade Road">Brigade Road (560025)</option>
                    <option value="12.9699,77.6077,Residency Road">Residency Road (560025)</option>
                    <option value="12.9802,77.6342,Ulsoor">Ulsoor (560008)</option>
                    <option value="12.9924,77.6159,Frazer Town">Frazer Town (560005)</option>
                </select>
            </div>
            
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 10px; font-weight: 600; font-size: 16px;"> Or enter coordinates:</label>
                <div style="display: flex; gap: 10px;">
                    <input type="number" id="manualLat" step="0.0001" placeholder="Latitude" style="flex: 1; padding: 10px; border: 2px solid #667eea; border-radius: 8px; font-size: 14px;">
                    <input type="number" id="manualLng" step="0.0001" placeholder="Longitude" style="flex: 1; padding: 10px; border: 2px solid #667eea; border-radius: 8px; font-size: 14px;">
                </div>
            </div>
            
            <div style="margin-bottom: 25px; padding: 15px; background: #f8f9ff; border-radius: 8px; border-left: 4px solid #667eea;">
                <p style="margin: 0; font-size: 14px; color: #666;">
                    <strong>💡 Tip:</strong> Choose a Bangalore area or enter coordinates to see crime risks. Your location will appear as a blue dot on the heatmap.
                </p>
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: center;">
                <button onclick="applyManualLocation()" class="btn btn-primary">📍 Set Location</button>
                <button onclick="closeModal()" class="btn btn-secondary">Cancel</button>
            </div>
        </div>
    `);
    
    // Add event listener for area select
    document.getElementById('areaSelect').addEventListener('change', function() {
        const value = this.value;
        if (value) {
            const parts = value.split(',');
            document.getElementById('manualLat').value = parts[0];
            document.getElementById('manualLng').value = parts[1];
        }
    });
}

function applyManualLocation() {
    const areaSelect = document.getElementById('areaSelect');
    const manualLat = document.getElementById('manualLat');
    const manualLng = document.getElementById('manualLng');
    
    let lat, lng, locationName;
    
    // Try area select first
    if (areaSelect.value) {
        const parts = areaSelect.value.split(',');
        lat = parseFloat(parts[0]);
        lng = parseFloat(parts[1]);
        locationName = parts[2] || 'Unknown';
    } 
    // Try coordinates
    else if (manualLat.value && manualLng.value) {
        lat = parseFloat(manualLat.value);
        lng = parseFloat(manualLng.value);
        locationName = `Coordinates (${lat.toFixed(4)}, ${lng.toFixed(4)})`;
    } else {
        alert('Please select an area or enter coordinates');
        return;
    }
    
    if (isNaN(lat) || isNaN(lng)) {
        alert('Please enter valid coordinates');
        return;
    }
    
    // Set the new location
    userLocation = { lat, lng };
    
    // Update status with success message
    const statusEl = document.getElementById('locationStatus');
    statusEl.innerHTML = `📍 <strong>${locationName}</strong> - Location set successfully!`;
    statusEl.style.color = '#4caf50';
    
    // Close modal
    closeModal();
    
    // Force redraw heatmap with new location
    console.log('Drawing heatmap with location:', userLocation);
    drawHeatmap();
    updateRiskAssessment();
    
    // Send alert notification for location change
    setTimeout(() => {
        sendNotification(`📍 Location Changed: ${locationName}`);
        
        // Show additional alert modal for location change
        showModal(`
            <div style="text-align: center;">
                <div style="font-size: 48px; margin-bottom: 20px;">🚨</div>
                <h4 style="color: #667eea; margin-bottom: 15px;">Location Updated!</h4>
                <div style="margin-bottom: 20px; padding: 15px; background: #f8f9ff; border-radius: 8px; border-left: 4px solid #667eea;">
                    <p style="margin: 0; font-size: 16px; color: #333;">
                        <strong>Your location has been set to:</strong><br>
                        <span style="color: #667eea; font-weight: 700;">${locationName}</span>
                    </p>
                </div>
                <div style="margin-bottom: 15px; padding: 15px; background: #fff3cd; border-radius: 8px; border-left: 4px solid #ffc107;">
                    <p style="margin: 0; font-size: 14px; color: #856404;">
                        <strong>⚠️ Risk Assessment Updated:</strong><br>
                        Check your risk level and take necessary precautions.
                    </p>
                </div>
                <div style="display: flex; gap: 10px; justify-content: center;">
                    <button onclick="closeModal()" class="btn btn-primary">📍 Got it!</button>
                </div>
            </div>
        `);
        
        // Auto-close the alert after 3 seconds
        setTimeout(() => {
            closeModal();
        }, 3000);
    }, 500);
}

async function getUserLocation() {
    const statusEl = document.getElementById('locationStatus');
    const btn = document.getElementById('locationBtn');
    
    if (!navigator.geolocation) {
        statusEl.textContent = 'Geolocation is not supported by your browser';
        return;
    }
    
    btn.disabled = true;
    statusEl.textContent = 'Getting your exact location...';
    
    // Try to get location with fallback for HTTP
    navigator.geolocation.getCurrentPosition(
        async (position) => {
            userLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            
            // Get exact location name from coordinates
            const locationName = await getLocationName(userLocation.lat, userLocation.lng);
            
            statusEl.innerHTML = `📍 <strong>${locationName}</strong> - Exact location found!`;
            statusEl.style.color = '#4caf50';
            btn.disabled = false;
            
            // Play success sound
            playSound('success');
            
            // Send detailed alert notification for exact location detection
            sendNotification(`📍 Exact Location Found: ${locationName}`);
            
            // Show detailed alert modal for exact location detection
            showModal(`
                <div style="text-align: center;">
                    <div style="font-size: 48px; margin-bottom: 20px;">📍</div>
                    <h4 style="color: #4caf50; margin-bottom: 15px;">Exact Location Detected!</h4>
                    <div style="margin-bottom: 20px; padding: 15px; background: #e8f5e8; border-radius: 8px; border-left: 4px solid #4caf50;">
                        <p style="margin: 0; font-size: 16px; color: #2e7d32;">
                            <strong>Your exact location:</strong><br>
                            <span style="color: #4caf50; font-weight: 700; font-size: 18px;">${locationName}</span>
                        </p>
                        <p style="margin: 10px 0 0 0; font-size: 14px; color: #2e7d32;">
                            <strong>📍 Coordinates:</strong> ${userLocation.lat.toFixed(6)}, ${userLocation.lng.toFixed(6)}
                        </p>
                    </div>
                    <div style="margin-bottom: 20px; padding: 15px; background: #fff3cd; border-radius: 8px; border-left: 4px solid #ffc107;">
                        <p style="margin: 0; font-size: 16px; color: #856404;">
                            <strong>🔍 Risk Assessment:</strong><br>
                            Calculating your crime risk level based on exact location...
                        </p>
                    </div>
                    <div style="display: flex; gap: 10px; justify-content: center;">
                        <button onclick="closeModal()" class="btn btn-primary">✅ Got it!</button>
                    </div>
                </div>
            `);
            
            // Auto-close the alert after 4 seconds
            setTimeout(() => {
                closeModal();
            }, 4000);
            
            // Redraw heatmap with exact user location
            drawHeatmap();
            
            // Calculate and show risk assessment
            const riskScore = calculateRiskScore(userLocation.lat, userLocation.lng);
            const riskText = getRiskText(riskScore);
            const riskLevel = getRiskLevelClass(riskScore);
            
            // Update risk display
            document.getElementById('riskScore').textContent = riskScore.toFixed(2);
            document.getElementById('riskText').textContent = riskText;
            document.getElementById('riskText').className = `risk-level ${riskLevel}`;
            
            // Play risk assessment sound
            setTimeout(() => {
                if (riskScore > 25) {
                    playSound('high-risk');
                } else if (riskScore > 10) {
                    playSound('medium-risk');
                } else {
                    playSound('low-risk');
                }
                
                // Show risk found alert
                sendNotification(`🚨 Risk Level Found: ${riskText} at ${locationName}`);
                
                // Update modal with risk information
                showModal(`
                    <div style="text-align: center;">
                        <div style="font-size: 48px; margin-bottom: 20px;">🚨</div>
                        <h4 style="color: #ff9800; margin-bottom: 15px;">Risk Assessment Complete!</h4>
                        <div style="margin-bottom: 20px; padding: 15px; background: #fff3cd; border-radius: 8px; border-left: 4px solid #ffc107;">
                            <p style="margin: 0; font-size: 16px; color: #856404;">
                                <strong>📍 Location:</strong> ${locationName}
                            </p>
                            <p style="margin: 10px 0 0 0; font-size: 14px; color: #856404;">
                                <strong>🚨 Risk Level:</strong> ${riskText}
                            </p>
                            <p style="margin: 10px 0 0 0; font-size: 14px; color: #856404;">
                                <strong>📊 Risk Score:</strong> ${riskScore.toFixed(2)}
                            </p>
                        </div>
                        <div style="display: flex; gap: 10px; justify-content: center;">
                            <button onclick="closeModal()" class="btn btn-primary">📍 Got it!</button>
                        </div>
                    </div>
                `);
                
                // Auto-close risk alert after 5 seconds
                setTimeout(() => {
                    closeModal();
                }, 5000);
            }, 1000);
        },
        async (error) => {
            console.log('Geolocation error:', error);
            
            // Play error sound
            playSound('error');
            
            // Fallback to default location for demo purposes
            if (error.message.includes('secure origins') || error.message.includes('HTTPS')) {
                userLocation = {
                    lat: 12.9716,  // Default: Bangalore MG Road
                    lng: 77.5946
                };
                
                const locationName = "MG Road, Bangalore (560001)";
                
                statusEl.innerHTML = `📍 <strong>${locationName}</strong> - Using demo location (HTTPS required)`;
                statusEl.style.color = '#ff9800';
                btn.disabled = false;
                
                // Play warning sound
                playSound('warning');
                
                // Send alert notification for demo location
                sendNotification(`🌍 Using Demo Location: ${locationName}`);
                
                // Show alert modal for demo location
                showModal(`
                    <div style="text-align: center;">
                        <div style="font-size: 48px; margin-bottom: 20px;">🌍</div>
                        <h4 style="color: #ff9800; margin-bottom: 15px;">Demo Location Set</h4>
                        <div style="margin-bottom: 20px; padding: 15px; background: #fff3cd; border-radius: 8px; border-left: 4px solid #ffc107;">
                            <p style="margin: 0; font-size: 16px; color: #856404;">
                                <strong>Using demo location:</strong><br>
                                <span style="color: #ff9800; font-weight: 700; font-size: 18px;">${locationName}</span>
                            </p>
                        </div>
                        <div style="margin-bottom: 20px; padding: 15px; background: #f8f9ff; border-radius: 8px; border-left: 4px solid #667eea;">
                            <p style="margin: 0; font-size: 14px; color: #333;">
                                <strong>ℹ️ Note:</strong><br>
                                Geolocation requires HTTPS for security. Using Bangalore demo location for demonstration.
                            </p>
                        </div>
                        <div style="display: flex; gap: 10px; justify-content: center;">
                            <button onclick="closeModal()" class="btn btn-primary">📍 Got it!</button>
                        </div>
                    </div>
                `);
                
                // Auto-close the alert after 4 seconds
                setTimeout(() => {
                    closeModal();
                }, 4000);
                
                // Redraw heatmap with demo location
                drawHeatmap();
                await updateRiskAssessment();
            } else {
                statusEl.textContent = `Error: ${error.message}`;
                btn.disabled = false;
                
                // Play error sound
                playSound('error');
            }
        }
    );
}

// Function to get location name from coordinates
async function getLocationName(lat, lng) {
    // Bangalore-specific location mapping
    const bangaloreAreas = [
        {name: "MG Road", lat: 12.9716, lng: 77.5946, pincode: "560001"},
        {name: "Majestic", lat: 12.9763, lng: 77.5713, pincode: "560003"},
        {name: "Koramangala", lat: 12.9279, lng: 77.6271, pincode: "560034"},
        {name: "Indiranagar", lat: 12.9784, lng: 77.6408, pincode: "560038"},
        {name: "Whitefield", lat: 12.9698, lng: 77.7499, pincode: "560066"},
        {name: "Jayanagar", lat: 12.9258, lng: 77.5803, pincode: "560041"},
        {name: "Basavanagudi", lat: 12.9405, lng: 77.5657, pincode: "560004"},
        {name: "HSR Layout", lat: 12.9116, lng: 77.6489, pincode: "560102"},
        {name: "Marathahalli", lat: 12.9591, lng: 77.6987, pincode: "560037"},
        {name: "Electronic City", lat: 12.8399, lng: 77.6770, pincode: "560100"},
        {name: "BTM Layout", lat: 12.9166, lng: 77.6101, pincode: "560076"},
        {name: "Bannerghatta Road", lat: 12.8701, lng: 77.5803, pincode: "560076"},
        {name: "Yelahanka", lat: 13.0955, lng: 77.5967, pincode: "560064"},
        {name: "Hebbal", lat: 13.0356, lng: 77.5967, pincode: "560024"},
        {name: "Airport Road", lat: 13.1986, lng: 77.7066, pincode: "560017"},
        {name: "Commercial Street", lat: 12.9795, lng: 77.6055, pincode: "560001"},
        {name: "Brigade Road", lat: 12.9775, lng: 77.6074, pincode: "560025"},
        {name: "Residency Road", lat: 12.9699, lng: 77.6077, pincode: "560025"},
        {name: "Ulsoor", lat: 12.9802, lng: 77.6342, pincode: "560008"},
        {name: "Frazer Town", lat: 12.9924, lng: 77.6159, pincode: "560005"}
    ];
    
    // Check if coordinates match any Bangalore area
    const tolerance = 0.01; // ~1km tolerance
    for (const area of bangaloreAreas) {
        if (Math.abs(lat - area.lat) < tolerance && Math.abs(lng - area.lng) < tolerance) {
            return `${area.name}, Bangalore (${area.pincode})`;
        }
    }
    
    // Fallback to coordinates if no Bangalore area found
    return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
}

function addUserMarker() {
    if (userLocation && typeof google !== 'undefined') {
        new google.maps.Marker({
            position: userLocation,
            map: map,
            title: "Your Location",
            icon: {
                path: google.maps.SymbolPath.CIRCLE,
                scale: 8,
                fillColor: '#4285F4',
                fillOpacity: 1,
                strokeColor: '#ffffff',
                strokeWeight: 2
            }
        });
    }
}

function updateAnalyticsWithCrimeData(data) {
    // Update analytics dashboard with crime data
    const riskDistribution = { "LOW": 0, "MEDIUM": 0, "HIGH": 0 };
    const totalCrimes = { "theft": 0, "assault": 0, "robbery": 0 };
    
    data.forEach(area => {
        riskDistribution[area.risk_level]++;
        totalCrimes.theft += area.theft;
        totalCrimes.assault += area.assault;
        totalCrimes.robbery += area.robbery;
    });
    
    updateAnalyticsDashboard({
        total_areas_monitored: data.length,
        risk_distribution: riskDistribution,
        total_crimes_reported: totalCrimes,
        high_risk_percentage: ((riskDistribution.HIGH / data.length) * 100).toFixed(1)
    });
}

// Store crime data globally for heatmap
let crimeDataPoints = [];

async function loadCrimeData() {
    try {
        console.log('Loading crime data from API...');
        const response = await fetch("/crime-data");
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('Crime data loaded successfully:', data.length, 'areas');
        
        // Store data for heatmap
        crimeDataPoints = data;
        
        // Update analytics
        updateAnalyticsWithCrimeData(data);
        
        // Draw custom heatmap
        drawHeatmap();
        
        // Setup mouse interactions
        setupCanvasInteractions();
        
    } catch (error) {
        console.error('Error loading crime data:', error);
        
        // Fallback to sample data if API fails
        console.log('Using fallback crime data...');
        crimeDataPoints = [
            {
                "area": "MG Road",
                "area_code": "560001",
                "lat": 12.9716,
                "lng": 77.5946,
                "theft": 12,
                "assault": 6,
                "robbery": 4,
                "risk_score": 40,
                "risk_level": "HIGH"
            },
            {
                "area": "Koramangala",
                "area_code": "560034",
                "lat": 12.9279,
                "lng": 77.6271,
                "theft": 8,
                "assault": 3,
                "robbery": 2,
                "risk_score": 22,
                "risk_level": "MEDIUM"
            },
            {
                "area": "Jayanagar",
                "area_code": "560041",
                "lat": 12.9258,
                "lng": 77.5803,
                "theft": 5,
                "assault": 2,
                "robbery": 1,
                "risk_score": 12,
                "risk_level": "LOW"
            }
        ];
        
        updateAnalyticsWithCrimeData(crimeDataPoints);
        drawHeatmap();
        setupCanvasInteractions();
    }
}

function drawHeatmap() {
    if (!window.heatmapCtx || !crimeDataPoints.length) {
        console.log('Heatmap not ready - missing context or data');
        return;
    }
    
    const ctx = window.heatmapCtx;
    const canvas = window.heatmapCanvas;
    const width = canvas.width;
    const height = canvas.height;
    
    console.log('Drawing heatmap with', crimeDataPoints.length, 'crime points');
    
    // Clear canvas with clean gradient background
    const bgGradient = ctx.createLinearGradient(0, 0, width, height);
    bgGradient.addColorStop(0, '#1a1a2e');
    bgGradient.addColorStop(0.5, '#16213e');
    bgGradient.addColorStop(1, '#0f3460');
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, width, height);
    
    // Draw subtle grid background (less clutter)
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.02)';
    ctx.lineWidth = 0.5;
    for (let i = 0; i < width; i += 60) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, height);
        ctx.stroke();
    }
    for (let i = 0; i < height; i += 60) {
        ctx.beginPath();
        ctx.moveTo(0, i);
        ctx.lineTo(width, i);
        ctx.stroke();
    }
    
    // Normalize coordinates to canvas space with better padding
    const padding = 100;
    const minLat = Math.min(...crimeDataPoints.map(p => p.lat));
    const maxLat = Math.max(...crimeDataPoints.map(p => p.lat));
    const minLng = Math.min(...crimeDataPoints.map(p => p.lng));
    const maxLng = Math.max(...crimeDataPoints.map(p => p.lng));
    
    console.log('Coordinate bounds:', {minLat, maxLat, minLng, maxLng});
    
    // Draw cleaner heatmap points with better spacing
    crimeDataPoints.forEach((area, index) => {
        const x = ((area.lng - minLng) / (maxLng - minLng)) * (width - padding * 2) + padding;
        const y = height - (((area.lat - minLat) / (maxLat - minLat)) * (height - padding * 2) + padding);
        
        // Cleaner heat circles with better visual separation
        const riskScore = area.risk_score;
        const maxRadius = Math.min(80, riskScore * 2.5); // Smaller, cleaner circles
        const time = Date.now() / 1000;
        const pulseEffect = Math.sin(time * 1.5 + index * 0.3) * 0.05 + 1; // Gentler pulse
        
        // Create cleaner gradient with fewer layers
        for (let layer = 3; layer >= 0; layer--) {
            const layerRadius = maxRadius * (layer + 1) / 3 * pulseEffect;
            const gradient = ctx.createRadialGradient(x, y, 0, x, y, layerRadius);
            
            // Cleaner color gradients
            if (riskScore > 25) {
                // HIGH RISK - Clean red gradient
                gradient.addColorStop(0, `rgba(244, 67, 54, ${0.9 - layer * 0.25})`);
                gradient.addColorStop(0.5, `rgba(255, 87, 87, ${0.5 - layer * 0.15})`);
                gradient.addColorStop(1, 'rgba(255, 138, 128, 0)');
            } else if (riskScore > 10 && riskScore <= 25) {
                // MEDIUM RISK - Clean orange gradient
                gradient.addColorStop(0, `rgba(255, 152, 0, ${0.9 - layer * 0.25})`);
                gradient.addColorStop(0.5, `rgba(255, 193, 7, ${0.5 - layer * 0.15})`);
                gradient.addColorStop(1, 'rgba(255, 235, 59, 0)');
            } else {
                // LOW RISK - Clean green gradient
                gradient.addColorStop(0, `rgba(76, 175, 80, ${0.9 - layer * 0.25})`);
                gradient.addColorStop(0.5, `rgba(139, 195, 74, ${0.5 - layer * 0.15})`);
                gradient.addColorStop(1, 'rgba(205, 220, 57, 0)');
            }
            
            ctx.fillStyle = gradient;
            ctx.fillRect(x - layerRadius, y - layerRadius, layerRadius * 2, layerRadius * 2);
        }
        
        // Cleaner center point
        ctx.beginPath();
        ctx.arc(x, y, 6 + pulseEffect, 0, 2 * Math.PI);
        
        // Subtle glow effect
        ctx.shadowBlur = 15;
        ctx.shadowColor = getRiskColor(area.risk_level);
        
        const centerGradient = ctx.createRadialGradient(x, y, 0, x, y, 6);
        centerGradient.addColorStop(0, '#ffffff');
        centerGradient.addColorStop(0.7, getRiskColor(area.risk_level));
        centerGradient.addColorStop(1, getRiskColor(area.risk_level));
        
        ctx.fillStyle = centerGradient;
        ctx.fill();
        
        // Reset shadow
        ctx.shadowBlur = 0;
        
        // Clean outer ring
        ctx.beginPath();
        ctx.arc(x, y, 9 + pulseEffect, 0, 2 * Math.PI);
        ctx.strokeStyle = getRiskColor(area.risk_level);
        ctx.lineWidth = 2;
        ctx.stroke();
        
        // Cleaner area name label (only show area name, no risk text on heatmap)
        if (index % 2 === 0) { // Show every other area name to reduce clutter
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 12px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
            ctx.shadowBlur = 4;
            ctx.shadowOffsetX = 1;
            ctx.shadowOffsetY = 1;
            
            // Background for text
            const textMetrics = ctx.measureText(area.area);
            const textWidth = textMetrics.width;
            const textHeight = 18;
            
            ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
            ctx.fillRect(x - textWidth/2 - 6, y - 35, textWidth + 12, textHeight);
            
            // Area name text
            ctx.fillStyle = '#ffffff';
            ctx.fillText(area.area, x, y - 26);
            
            // Reset shadow
            ctx.shadowBlur = 0;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 0;
        }
        
        // Store position for interaction
        area.canvasX = x;
        area.canvasY = y;
    });
    
    // Enhanced user location with cleaner effects
    if (userLocation) {
        const userX = ((userLocation.lng - minLng) / (maxLng - minLng)) * (width - padding * 2) + padding;
        const userY = height - (((userLocation.lat - minLat) / (maxLat - minLat)) * (height - padding * 2) + padding);
        
        const time = Date.now() / 1000;
        const pulseSize = 10 + Math.sin(time * 2) * 3;
        
        // Cleaner pulsing rings
        for (let i = 3; i >= 0; i--) {
            const ringRadius = pulseSize + i * 8;
            const ringOpacity = 0.6 - i * 0.15;
            
            ctx.beginPath();
            ctx.arc(userX, userY, ringRadius, 0, 2 * Math.PI);
            ctx.strokeStyle = `rgba(79, 172, 254, ${ringOpacity})`;
            ctx.lineWidth = 2;
            ctx.stroke();
        }
        
        // Cleaner user location center
        ctx.beginPath();
        ctx.arc(userX, userY, pulseSize, 0, 2 * Math.PI);
        
        const userGradient = ctx.createRadialGradient(userX, userY, 0, userX, userY, pulseSize);
        userGradient.addColorStop(0, '#ffffff');
        userGradient.addColorStop(0.4, '#4facfe');
        userGradient.addColorStop(1, '#00d2ff');
        
        ctx.fillStyle = userGradient;
        ctx.shadowBlur = 20;
        ctx.shadowColor = '#4facfe';
        ctx.fill();
        ctx.shadowBlur = 0;
        
        // Enhanced user icon
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('👤', userX, userY);
        
        // User location label
        ctx.font = 'bold 10px Arial';
        ctx.fillStyle = 'rgba(79, 172, 254, 0.9)';
        ctx.fillText('YOUR LOCATION', userX, userY + pulseSize + 18);
        
        console.log('User location drawn at:', {userX, userY});
    }
    
    console.log('Heatmap drawing completed');
}

function setupCanvasInteractions() {
    const canvas = window.heatmapCanvas;
    const tooltip = document.getElementById('tooltip');
    
    canvas.addEventListener('mousemove', (e) => {
        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        // Check if hovering over a crime point
        const hoveredArea = crimeDataPoints.find(area => {
            if (!area.canvasX || !area.canvasY) return false;
            const distance = Math.sqrt(Math.pow(x - area.canvasX, 2) + Math.pow(y - area.canvasY, 2));
            return distance < 20;
        });
        
        if (hoveredArea) {
            // Get proper risk description
            let riskDescription = '';
            let riskColor = '';
            
            if (hoveredArea.risk_level === 'HIGH') {
                riskDescription = 'High Risk - Be cautious';
                riskColor = '#f44336';
            } else if (hoveredArea.risk_level === 'MEDIUM') {
                riskDescription = 'Medium Risk - Stay alert';
                riskColor = '#ff9800';
            } else {
                riskDescription = 'Low Risk - Generally safe';
                riskColor = '#4caf50';
            }
            
            tooltip.style.display = 'block';
            tooltip.style.left = (e.clientX - rect.left + 10) + 'px';
            tooltip.style.top = (e.clientY - rect.top - 30) + 'px';
            tooltip.innerHTML = `
                <div style="font-weight: 700; margin-bottom: 5px; color: ${riskColor};">${hoveredArea.area}</div>
                <div style="font-size: 11px; opacity: 0.9;">${riskDescription}</div>
                <div style="font-size: 10px; margin-top: 3px;">Pincode: ${hoveredArea.area_code || 'N/A'}</div>
                <div style="font-size: 10px; margin-top: 2px;">Risk Score: ${hoveredArea.risk_score}</div>
                <div style="font-size: 10px; margin-top: 2px;">🚨 Theft: ${hoveredArea.theft} | ⚔️ Assault: ${hoveredArea.assault} | 🔫 Robbery: ${hoveredArea.robbery}</div>
            `;
        } else {
            tooltip.style.display = 'none';
        }
    });
    
    canvas.addEventListener('mouseleave', () => {
        tooltip.style.display = 'none';
    });
    
    // Animate heatmap
    setInterval(() => {
        drawHeatmap();
    }, 100);
}

function addAreaMarker(area) {
    const color = getRiskColor(area.risk_level);
    
    const marker = new google.maps.Marker({
        position: { lat: area.lat, lng: area.lng },
        map: map,
        title: `${area.area} - ${area.risk_level} RISK`,
        icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: 6,
            fillColor: color,
            fillOpacity: 0.8,
            strokeColor: '#ffffff',
            strokeWeight: 2
        }
    });
    
    const infoWindow = new google.maps.InfoWindow({
        content: `
            <div style="padding: 10px; font-family: Arial, sans-serif;">
                <h4 style="margin: 0 0 10px 0; color: #333;">${area.area}</h4>
                <p style="margin: 5px 0;"><strong>Risk Level:</strong> <span style="color: ${color}; font-weight: bold;">${area.risk_level}</span></p>
                <p style="margin: 5px 0;"><strong>Risk Score:</strong> ${area.risk_score}</p>
                <p style="margin: 5px 0;"><strong>Theft:</strong> ${area.theft} | <strong>Assault:</strong> ${area.assault} | <strong>Robbery:</strong> ${area.robbery}</p>
            </div>
        `
    });
    
    marker.addListener('click', () => {
        infoWindow.open(map, marker);
    });
    
    markers.push(marker);
}

function getRiskColor(riskLevel) {
    switch(riskLevel) {
        case 'HIGH': return '#f44336';
        case 'MEDIUM': return '#ff9800';
        case 'LOW': return '#4caf50';
        default: return '#9e9e9e';
    }
}

function clearMapOverlays() {
    markers.forEach(marker => marker.setMap(null));
    markers = [];
    
    if (heatmap) {
        heatmap.setMap(null);
        heatmap = null;
    }
}

async function updateRiskAssessment() {
    if (!userLocation) return;
    
    try {
        const response = await fetch(`/risk-assessment?lat=${userLocation.lat}&lng=${userLocation.lng}`);
        const data = await response.json();
        
        updateRiskCard(data);
        
        if (data.immediate_risk === 'HIGH' || data.immediate_risk === 'MEDIUM') {
            showAlert(data);
        }
        
    } catch (error) {
        console.error('Error updating risk assessment:', error);
    }
}

function updateRiskCard(data) {
    const riskLevel = document.getElementById('riskLevel');
    const riskScore = document.getElementById('riskScore');
    const riskRecommendation = document.getElementById('riskRecommendation');
    const riskIndicator = document.getElementById('riskIndicator');
    
    riskLevel.textContent = data.immediate_risk;
    riskScore.textContent = data.risk_score;
    riskRecommendation.textContent = data.recommendation;
    
    riskIndicator.className = `risk-indicator ${data.immediate_risk.toLowerCase()}`;
}

async function loadAnalytics() {
    try {
        const response = await fetch("/analytics/summary");
        const data = await response.json();
        
        updateAnalyticsDashboard(data);
        
    } catch (error) {
        console.error('Error loading analytics:', error);
    }
}

function updateAnalyticsDashboard(data) {
    document.getElementById('totalAreas').textContent = data.total_areas_monitored;
    document.getElementById('highRiskCount').textContent = data.risk_distribution.HIGH;
    
    document.getElementById('lowCount').textContent = data.risk_distribution.LOW;
    document.getElementById('mediumCount').textContent = data.risk_distribution.MEDIUM;
    document.getElementById('highCount').textContent = data.risk_distribution.HIGH;
    
    const total = data.total_areas_monitored;
    document.getElementById('lowBar').style.width = `${(data.risk_distribution.LOW / total) * 100}%`;
    document.getElementById('mediumBar').style.width = `${(data.risk_distribution.MEDIUM / total) * 100}%`;
    document.getElementById('highBar').style.width = `${(data.risk_distribution.HIGH / total) * 100}%`;
    
    document.getElementById('theftCount').textContent = data.total_crimes_reported.theft;
    document.getElementById('assaultCount').textContent = data.total_crimes_reported.assault;
    document.getElementById('robberyCount').textContent = data.total_crimes_reported.robbery;
}

async function refreshData() {
    const btn = document.getElementById('refreshBtn');
    const originalHTML = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Refreshing...';
    btn.disabled = true;
    
    await loadCrimeData();
    await loadAnalytics();
    
    if (userLocation) {
        await updateRiskAssessment();
    }
    
    setTimeout(() => {
        btn.innerHTML = originalHTML;
        btn.disabled = false;
    }, 1000);
}

async function simulateAlert() {
    try {
        const response = await fetch("/simulate/real-time-update");
        const data = await response.json();
        
        addAlertToList(data);
        showModal(data.message);
        sendNotification(data.message);
        
        // Reload data to update heatmap
        await loadCrimeData();
        await loadAnalytics();
        
        if (userLocation) {
            await updateRiskAssessment();
        }
        
    } catch (error) {
        console.error('Error simulating alert:', error);
    }
}

function addAlertToList(alertData) {
    const alertsList = document.getElementById('alertsList');
    
    if (alerts.length === 0) {
        alertsList.innerHTML = '';
    }
    
    const alertItem = document.createElement('div');
    alertItem.className = `alert-item ${alertData.new_risk_level.toLowerCase()}`;
    
    const iconClass = alertData.new_risk_level === 'HIGH' ? 'fas fa-exclamation-triangle' : 
                     alertData.new_risk_level === 'MEDIUM' ? 'fas fa-exclamation-circle' : 
                     'fas fa-info-circle';
    
    alertItem.innerHTML = `
        <div class="alert-icon">
            <i class="${iconClass}"></i>
        </div>
        <div class="alert-content">
            <div class="alert-title">${alertData.crime_type} in ${alertData.area}</div>
            <div class="alert-message">${alertData.message}</div>
            <div class="alert-time">${new Date(alertData.timestamp).toLocaleTimeString()}</div>
        </div>
    `;
    
    alertsList.insertBefore(alertItem, alertsList.firstChild);
    alerts.unshift(alertData);
    
    if (alerts.length > 10) {
        alerts.pop();
        alertsList.removeChild(alertsList.lastChild);
    }
}

function showAlert(data) {
    const modal = document.getElementById('notificationModal');
    const modalMessage = document.getElementById('modalMessage');
    
    modalMessage.innerHTML = `
        <div style="text-align: center;">
            <div style="font-size: 48px; margin-bottom: 20px; color: ${getRiskColor(data.immediate_risk)};">
                ${data.immediate_risk === 'HIGH' ? '⚠️' : data.immediate_risk === 'MEDIUM' ? '⚡' : '✅'}
            </div>
            <h4 style="margin: 0 0 15px 0; color: #333;">Risk Level: ${data.immediate_risk}</h4>
            <p style="margin: 0 0 10px 0; font-size: 16px;"><strong>Risk Score:</strong> ${data.risk_score}</p>
            <p style="margin: 0; color: #666; line-height: 1.5;">${data.recommendation}</p>
        </div>
    `;
    
    modal.style.display = 'block';
}

function showModal(message) {
    const modal = document.getElementById('notificationModal');
    const modalMessage = document.getElementById('modalMessage');
    
    modalMessage.innerHTML = `<p>${message}</p>`;
    modal.style.display = 'block';
}

function closeModal() {
    document.getElementById('notificationModal').style.display = 'none';
}

function requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
}

function sendNotification(message) {
    // Check if browser supports notifications
    if (!("Notification" in window)) {
        console.log("This browser does not support desktop notification");
        return;
    }
    
    // Check if permission is already granted
    if (Notification.permission === "granted") {
        // Create notification
        const notification = new Notification("🚨 ALERTX Safety Alert", {
            body: message,
            icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23667eea'><path d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z'/></svg>",
            badge: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23667eea'><circle cx='12' cy='12' r='10'/></svg>",
            tag: 'alertx-notification',
            requireInteraction: false,
            silent: false
        });
        
        // Auto close after 5 seconds
        setTimeout(() => {
            notification.close();
        }, 5000);
        
        // Handle notification click
        notification.onclick = function() {
            window.focus();
            notification.close();
        };
        
        console.log('Notification sent:', message);
        
    } else if (Notification.permission !== "denied") {
        // Request permission
        Notification.requestPermission().then(function (permission) {
            if (permission === "granted") {
                sendNotification(message); // Retry after permission granted
            }
        });
    } else {
        console.log("Notification permission denied");
        // Show in-app notification as fallback
        showInAppNotification(message);
    }
}

function showInAppNotification(message) {
    // Create in-app notification as fallback
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
        padding: 15px 20px;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        z-index: 10000;
        max-width: 300px;
        font-size: 14px;
        animation: slideIn 0.3s ease;
        border: 1px solid rgba(255,255,255,0.2);
        backdrop-filter: blur(10px);
    `;
    notification.innerHTML = `
        <div style="font-weight: 700; margin-bottom: 5px;">🚨 ALERTX Safety Alert</div>
        <div style="opacity: 0.9;">${message}</div>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
    
    // Add animation styles if not already present
    if (!document.getElementById('notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
}

window.onclick = function(event) {
    const modal = document.getElementById('notificationModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
}

// Manual initialization fallback
setTimeout(() => {
    if (typeof window.initMap === 'function' && !window.mapInitialized) {
        console.log('ALERTX: Manual initialization fallback');
        window.initMap();
        window.mapInitialized = true;
    }
}, 2000);

if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(registration => console.log('ServiceWorker registered'))
        .catch(error => console.log('ServiceWorker registration failed:', error));
}

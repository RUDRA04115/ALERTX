const CACHE_NAME = 'alertx-v1';
const urlsToCache = [
    '/',
    '/index.html',
    '/style.css',
    '/main.js',
    '/manifest.json'
];

self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                return cache.addAll(urlsToCache);
            })
    );
});

self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request)
            .then(response => {
                if (response) {
                    return response;
                }
                return fetch(event.request);
            })
    );
});

self.addEventListener('sync', event => {
    if (event.tag === 'background-sync') {
        event.waitUntil(doBackgroundSync());
    }
});

async function doBackgroundSync() {
    try {
        const response = await fetch('/crime-data');
        const data = await response.json();
        
        const highRiskAreas = data.filter(area => area.risk_level === 'HIGH');
        
        if (highRiskAreas.length > 0) {
            self.registration.showNotification('ALERTX Safety Update', {
                body: `${highRiskAreas.length} high-risk areas detected. Check the app for details.`,
                icon: '/favicon.ico',
                badge: '/favicon.ico',
                tag: 'alertx-background',
                requireInteraction: true,
                actions: [
                    {
                        action: 'open',
                        title: 'Open ALERTX'
                    },
                    {
                        action: 'dismiss',
                        title: 'Dismiss'
                    }
                ]
            });
        }
    } catch (error) {
        console.log('Background sync failed:', error);
    }
}

self.addEventListener('push', event => {
    const options = {
        body: event.data ? event.data.text() : 'New safety alert available',
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        vibrate: [100, 50, 100],
        data: {
            dateOfArrival: Date.now(),
            primaryKey: 1
        },
        actions: [
            {
                action: 'explore',
                title: 'View Details',
                icon: '/images/checkmark.png'
            },
            {
                action: 'close',
                title: 'Close',
                icon: '/images/xmark.png'
            }
        ]
    };

    event.waitUntil(
        self.registration.showNotification('ALERTX Alert', options)
    );
});

self.addEventListener('notificationclick', event => {
    event.notification.close();

    if (event.action === 'open' || event.action === 'explore') {
        event.waitUntil(
            clients.openWindow('/')
        );
    }
});

self.addEventListener('activate', event => {
    const cacheWhitelist = [CACHE_NAME];
    
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheWhitelist.indexOf(cacheName) === -1) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});

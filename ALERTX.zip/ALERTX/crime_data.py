crime_data = [
    {
        "area": "MG Road",
        "area_code": "560001",
        "lat": 12.9716,
        "lng": 77.5946,
        "theft": 12,
        "assault": 6,
        "robbery": 4
    },
    {
        "area": "Majestic",
        "area_code": "560003",
        "lat": 12.9763,
        "lng": 77.5713,
        "theft": 20,
        "assault": 10,
        "robbery": 8
    },
    {
        "area": "Koramangala",
        "area_code": "560034",
        "lat": 12.9279,
        "lng": 77.6271,
        "theft": 8,
        "assault": 3,
        "robbery": 2
    },
    {
        "area": "Indiranagar",
        "area_code": "560038",
        "lat": 12.9784,
        "lng": 77.6408,
        "theft": 15,
        "assault": 7,
        "robbery": 5
    },
    {
        "area": "Whitefield",
        "area_code": "560066",
        "lat": 12.9698,
        "lng": 77.7499,
        "theft": 18,
        "assault": 9,
        "robbery": 6
    },
    {
        "area": "Jayanagar",
        "area_code": "560041",
        "lat": 12.9258,
        "lng": 77.5803,
        "theft": 5,
        "assault": 2,
        "robbery": 1
    },
    {
        "area": "Basavanagudi",
        "area_code": "560004",
        "lat": 12.9405,
        "lng": 77.5657,
        "theft": 7,
        "assault": 3,
        "robbery": 2
    },
    {
        "area": "HSR Layout",
        "area_code": "560102",
        "lat": 12.9116,
        "lng": 77.6489,
        "theft": 10,
        "assault": 4,
        "robbery": 3
    },
    {
        "area": "Marathahalli",
        "area_code": "560037",
        "lat": 12.9591,
        "lng": 77.6987,
        "theft": 22,
        "assault": 12,
        "robbery": 9
    },
    {
        "area": "Electronic City",
        "area_code": "560100",
        "lat": 12.8399,
        "lng": 77.6770,
        "theft": 14,
        "assault": 6,
        "robbery": 4
    },
    {
        "area": "BTM Layout",
        "area_code": "560076",
        "lat": 12.9166,
        "lng": 77.6101,
        "theft": 16,
        "assault": 8,
        "robbery": 6
    },
    {
        "area": "Bannerghatta Road",
        "area_code": "560076",
        "lat": 12.8701,
        "lng": 77.5803,
        "theft": 11,
        "assault": 5,
        "robbery": 3
    },
    {
        "area": "Yelahanka",
        "area_code": "560064",
        "lat": 13.0955,
        "lng": 77.5967,
        "theft": 6,
        "assault": 2,
        "robbery": 1
    },
    {
        "area": "Hebbal",
        "area_code": "560024",
        "lat": 13.0356,
        "lng": 77.5967,
        "theft": 9,
        "assault": 4,
        "robbery": 3
    },
    {
        "area": "Airport Road",
        "area_code": "560017",
        "lat": 13.1986,
        "lng": 77.7066,
        "theft": 4,
        "assault": 1,
        "robbery": 1
    },
    {
        "area": "Commercial Street",
        "area_code": "560001",
        "lat": 12.9795,
        "lng": 77.6055,
        "theft": 25,
        "assault": 14,
        "robbery": 10
    },
    {
        "area": "Brigade Road",
        "area_code": "560025",
        "lat": 12.9775,
        "lng": 77.6074,
        "theft": 18,
        "assault": 8,
        "robbery": 6
    },
    {
        "area": "Residency Road",
        "area_code": "560025",
        "lat": 12.9699,
        "lng": 77.6077,
        "theft": 12,
        "assault": 5,
        "robbery": 3
    },
    {
        "area": "Ulsoor",
        "area_code": "560008",
        "lat": 12.9802,
        "lng": 77.6342,
        "theft": 8,
        "assault": 3,
        "robbery": 2
    },
    {
        "area": "Frazer Town",
        "area_code": "560005",
        "lat": 12.9924,
        "lng": 77.6159,
        "theft": 10,
        "assault": 4,
        "robbery": 3
    }
]

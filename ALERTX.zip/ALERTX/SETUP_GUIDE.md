# ALERTX Setup Guide

## 🚨 Google Maps API Issue

The application is currently showing a Google Maps error because the API key needs to be configured for your domain.

## 🔧 Quick Fix Options

### Option 1: Get Your Own Google Maps API Key (Recommended)

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable these APIs:
   - Maps JavaScript API
   - Maps Visualization API
4. Create an API key
5. Replace the key in `index.html` line 182:

```html
<script async defer src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY_HERE&libraries=visualization&callback=initMap"></script>
```

### Option 2: Use Without Maps (Current Fallback)

The app will work perfectly without Google Maps:
- ✅ All backend features work
- ✅ Location tracking works
- ✅ Risk assessment works
- ✅ Analytics dashboard works
- ✅ Notifications work
- ❌ Map visualization shows fallback message

## 🚀 Running the Application

### Method 1: Single Server (Recommended)
```bash
cd ALERTX
pip install -r requirements.txt
python app.py
```
Then open: http://127.0.0.1:5000

### Method 2: Development Mode
```bash
# Terminal 1 - Backend
cd ALERTX
python app.py

# Terminal 2 - Frontend (for development)
cd ALERTX
python -m http.server 8000
```
Then open: http://localhost:8000

## 🎯 Features Working Right Now

Even without Google Maps, these features are fully functional:

1. **📍 Location Services**: Click "Get My Location"
2. **🤖 AI Risk Assessment**: Personalized safety scoring
3. **📊 Analytics Dashboard**: Real-time crime statistics
4. **🔔 Smart Notifications**: Browser push alerts
5. **⚡ Real-time Updates**: Simulated crime alerts
6. **📱 PWA Features**: Installable web app

## 🏆 Demo Mode

For hackathon demos, the current setup is perfect:
- Shows all core functionality
- Demonstrates AI risk algorithm
- Interactive and responsive
- No API key dependency for core features

## 📱 Mobile Testing

The app works great on mobile:
- Responsive design adapts to screen size
- Touch-friendly interface
- PWA installable on home screen
- Location services work on mobile browsers

---

**Note**: The Google Maps API key issue only affects map visualization. All other ALERTX features work perfectly without it.

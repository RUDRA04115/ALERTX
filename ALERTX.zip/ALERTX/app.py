from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from crime_data import crime_data
import math
from datetime import datetime, timedelta
import random
import os

app = Flask(__name__, static_folder='.')
CORS(app)

def calculate_risk(area):
    score = (
        area["theft"] * 1 +
        area["assault"] * 2 +
        area["robbery"] * 3
    )

    if score > 25:
        risk = "HIGH"
    elif score > 10:
        risk = "MEDIUM"
    else:
        risk = "LOW"

    return score, risk

def calculate_distance(lat1, lng1, lat2, lng2):
    R = 6371
    dLat = math.radians(lat2 - lat1)
    dLng = math.radians(lng2 - lng1)
    a = (math.sin(dLat/2)**2 + 
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * 
         math.sin(dLng/2)**2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c

@app.route("/crime-data")
def get_crime_data():
    result = []
    for area in crime_data:
        score, risk = calculate_risk(area)
        area["risk_score"] = score
        area["risk_level"] = risk
        area["last_updated"] = datetime.now().isoformat()
        result.append(area)
    return jsonify(result)

@app.route("/crime-data/nearby")
def get_nearby_crime_data():
    lat = float(request.args.get('lat', 12.9716))
    lng = float(request.args.get('lng', 77.5946))
    radius_km = float(request.args.get('radius', 5))
    
    nearby_areas = []
    for area in crime_data:
        distance = calculate_distance(lat, lng, area["lat"], area["lng"])
        if distance <= radius_km:
            area_copy = area.copy()
            area_copy["distance_km"] = round(distance, 2)
            score, risk = calculate_risk(area_copy)
            area_copy["risk_score"] = score
            area_copy["risk_level"] = risk
            area_copy["last_updated"] = datetime.now().isoformat()
            nearby_areas.append(area_copy)
    
    nearby_areas.sort(key=lambda x: x["distance_km"])
    return jsonify(nearby_areas)

@app.route("/risk-assessment")
def get_risk_assessment():
    lat = float(request.args.get('lat', 12.9716))
    lng = float(request.args.get('lng', 77.5946))
    
    nearby_areas = []
    for area in crime_data:
        distance = calculate_distance(lat, lng, area["lat"], area["lng"])
        if distance <= 3:
            score, risk = calculate_risk(area)
            nearby_areas.append({"distance": distance, "score": score, "risk": risk})
    
    if not nearby_areas:
        return jsonify({
            "user_location": {"lat": lat, "lng": lng},
            "immediate_risk": "LOW",
            "risk_score": 0,
            "nearby_threats": 0,
            "recommendation": "Area appears safe. Continue monitoring."
        })
    
    avg_score = sum(a["score"] for a in nearby_areas) / len(nearby_areas)
    high_risk_count = sum(1 for a in nearby_areas if a["risk"] == "HIGH")
    
    if avg_score > 20 or high_risk_count >= 2:
        immediate_risk = "HIGH"
        recommendation = "⚠️ HIGH RISK: Avoid this area. Take alternative routes."
    elif avg_score > 10 or high_risk_count >= 1:
        immediate_risk = "MEDIUM"
        recommendation = "⚡ MEDIUM RISK: Stay alert, avoid isolated areas."
    else:
        immediate_risk = "LOW"
        recommendation = "✅ LOW RISK: Area appears safe. Standard precautions advised."
    
    return jsonify({
        "user_location": {"lat": lat, "lng": lng},
        "immediate_risk": immediate_risk,
        "risk_score": round(avg_score, 1),
        "nearby_threats": len(nearby_areas),
        "recommendation": recommendation,
        "assessment_time": datetime.now().isoformat()
    })

@app.route("/analytics/summary")
def get_analytics_summary():
    total_areas = len(crime_data)
    risk_distribution = {"LOW": 0, "MEDIUM": 0, "HIGH": 0}
    total_crimes = {"theft": 0, "assault": 0, "robbery": 0}
    
    for area in crime_data:
        score, risk = calculate_risk(area)
        risk_distribution[risk] += 1
        total_crimes["theft"] += area["theft"]
        total_crimes["assault"] += area["assault"]
        total_crimes["robbery"] += area["robbery"]
    
    return jsonify({
        "total_areas_monitored": total_areas,
        "risk_distribution": risk_distribution,
        "total_crimes_reported": total_crimes,
        "high_risk_percentage": round((risk_distribution["HIGH"] / total_areas) * 100, 1),
        "last_updated": datetime.now().isoformat()
    })

@app.route("/simulate/real-time-update")
def simulate_real_time_update():
    random_area = random.choice(crime_data)
    crime_type = random.choice(["theft", "assault", "robbery"])
    random_area[crime_type] = random.randint(1, 10)
    
    score, risk = calculate_risk(random_area)
    
    return jsonify({
        "alert_type": "CRIME_UPDATE",
        "area": random_area["area"],
        "coordinates": {"lat": random_area["lat"], "lng": random_area["lng"]},
        "crime_type": crime_type.upper(),
        "new_risk_level": risk,
        "risk_score": score,
        "timestamp": datetime.now().isoformat(),
        "message": f"New {crime_type} incident reported in {random_area['area']}. Current risk level: {risk}"
    })

@app.route('/')
def serve_index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('.', path)

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5000)
